Latest JUnit 3.7 jar downloaded from http://www.junit.org/
