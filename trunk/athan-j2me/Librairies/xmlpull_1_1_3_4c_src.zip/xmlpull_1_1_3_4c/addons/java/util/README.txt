placeholder for utility functions for XmlPull API
