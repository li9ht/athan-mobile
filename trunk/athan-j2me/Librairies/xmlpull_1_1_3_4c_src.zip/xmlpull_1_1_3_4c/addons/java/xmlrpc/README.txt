XML-RPC implementation that uses XmlPull API

